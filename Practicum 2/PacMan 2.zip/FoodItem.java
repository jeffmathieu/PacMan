package pacman;

public abstract class FoodItem {
	
	
	/**
	 * @basic
	 */
	
	public abstract Square getSquare() ;
	
	/**
	 * @basic
	 */
	
	public abstract int getSize() ;
	
}
